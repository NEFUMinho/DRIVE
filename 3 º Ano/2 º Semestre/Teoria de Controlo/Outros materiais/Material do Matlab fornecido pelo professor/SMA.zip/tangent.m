function [tv, f, idx] = tangent(y, t)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
h = mean(diff(t));
dy = gradient(y, h); 
[~,idx] = max(dy); 
b = [t([idx-1,idx+1]) ones(2,1)] \ y([idx-1,idx+1]);            % Regression Line Around Maximum Derivative
tv = [-b(2)/b(1); (1-b(2))/b(1)];                               % Independent Variable Range For Tangent Line Plot
f = [tv ones(2,1)] * b;                                         % Calculate Tangent Line
end

