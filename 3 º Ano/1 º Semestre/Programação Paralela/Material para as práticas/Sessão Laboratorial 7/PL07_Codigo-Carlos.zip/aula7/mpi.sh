#!/bin/bash
#SBATCH --time=1:00
#SBATCH --ntasks=5
#SBATCH --partition=cpar

mpirun -np 5 ./a.out 

'''   Este programa especifica os recursos fornecidos,
      além de correr o programa "mpi"   

      Note that the number of requested resources (--ntasks) must be the same 
      as the number of resources used in the mpirun command.
'''
