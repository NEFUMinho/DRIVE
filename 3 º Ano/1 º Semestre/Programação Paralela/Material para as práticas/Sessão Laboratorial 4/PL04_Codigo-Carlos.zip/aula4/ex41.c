#include<omp.h>
#include<stdio.h>

/* 

uma thread é um fio de execução, basicamente a entidade que vai executar algum codigo em paralelo
se tivermos dois fios de execução, significa que existe uma parte da aplicação que é executada em paralelo com a outra parte da aplicação
fios só sao uma abrastração ao sft para indicar as tarefas que podemos executar em paralelo aos cores físicos. 

*/

int main() {
    
    printf("master thread\n");

    #pragma omp parallel num_threads(2) //indica o numero de threads a serem utilizadas

    //#pragma omp for      // a thread 0 faz de 0 a 49 e a thread 1 faz de 50 a 99 (há distribuição de carga), porém o output depende da thread que chegar primeiro à região paralela
    //#pragma omp master   // a thread 0 faz tudo sozinho (a thread 0 é sempre a mestre!!!)
    //#pragma omp single   // a thread 0 faz tudo sozinho (no single é a primeira thread que chegar lá)
    //#pragma omp critical   // as duas threads fazem 100 cada uma (enquanto uma thread estiver dentro da critical(a primeira a chegar ao escalonador), a outra tem que esperar, sendo que existe sempre a mesma ordem de apresentação (tipo corrida de estafetas); existe controlo de fluxo)

    //#pragma omp for ordered // feito em conj. com o pragma antes do printf dentro do for (ex.2)

    //#pragma omp for schedule(static)   // é feita uma divisão entre as threads das iterações/cargas (50/50), porém em intervalos irregulares (é o que é feito by default/por omissão), os quais serão igualmente apresentados em output irregularmente
                                         // a divisao estatica vai deixar de ser util quando existem iterações mais demoradas do que outras (nesse caso umas das threads vai suportar mais carga que a outra)
    //#pragma omp for schedule(static,10)  // divide em intervalos de 10 em 10 as cargas, isto é, t_0 fica com as cargas 0 a 9, 20 a 29,... e a t_1 fica com os intervalos no meio, porém a ordem de chegada no print vai variar
    //#pragma omp for schedule(dynamic) // é feita uma divisão de cargas entre as threads mas de forma desconhecida e irregular, sempre que uma thread estiver disponível, vai pedir ao escalonador mais cargas
                                      
    //#pragma omp for schedule(dynamic,10) // é feita a divisão em blocos de 10 cargas, porém o escalonador nao indica os intervalos das cargas, assim sempre que a thread 0, p.ex., faz 10 cargas pede mais 10, nao significando que entre elas tenham exatamente 10 cargas
    //#pragma omp for schedule(guided)  // semelhante à "dynamic" mas o tamanho da divisão em blocos diminui durante a execução

    for(int i=0;i<100;i++) {

        int id = omp_get_thread_num();

        //#pragma omp ordered  // obriga que as iterações sejam feitas por ordem, de acordo com a divisão feita entre as threads

        printf("T%d:i%d ", id, i);
         
        //(a proxima esta em conjunto com o omp for ordered) 
        //#pragma omp barrier    //  neste caso, executa o ciclo for uma vez para cada thread, ou seja, a thread 0 faz uma vez o ciclo e depois antes de fazer outro, a thread 1 realiza o ciclo, e assim sucessivamente
                               // neste pragma, a ordem de output das threads varia 
    }
    
    printf("master thread\n");

}