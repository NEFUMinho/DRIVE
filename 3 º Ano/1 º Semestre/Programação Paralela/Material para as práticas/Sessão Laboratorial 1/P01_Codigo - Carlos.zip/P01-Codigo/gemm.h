#ifndef __GEMM__
#define __GEMM__

void gemm1  (float *a, float *b, float *c, int m_size);
void gemm2  (float *a, float *b, float *c, int m_size);
void gemm3  (float *a, float *b, float *c, int m_size);
void gemm4  (float *a, float *b, float *c, int m_size);
void gemm5  (float *a, float *b, float *c, int m_size);
void gemm6  (float *a, float *b, float *c, int m_size);
void gemm7  (float *a, float *b, float *c, int m_size);
void gemm8  (float *a, float *b, float *c, int m_size);
void gemm9  (float *a, float *b, float *c, int m_size);
void gemm10  (float *a, float *b, float *c, int m_size);

#endif

