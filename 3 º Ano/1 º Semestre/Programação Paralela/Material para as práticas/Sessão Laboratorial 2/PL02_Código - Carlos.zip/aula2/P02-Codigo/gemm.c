#include <stdio.h>
#include "gemm.h"

/*
 * gemm1
 * Algoritmo não optimizado
 */

void gemm1  (float *a, float *b, float *c, int n) {
	int i, j, k;
	float cij;

	for (i = 0; i < n; ++i) {
		for (j = 0; j < n; ++j) {
			cij = c[i*n+j]; /* cij = C[i][j] */
			for(k = 0; k < n; k++ ) {
				cij += a[i*n+k] * b[k*n+j]; /* cij += A[i][k]*B[k][j] */
			}
			c[i*n+j] = cij; /* C[i][j] = cij */
		}
	}
}


/*
 * gemm2
 * Algoritmo B transposed !!!!!!!!! b[k][j] -> b[j][k]
 */

void gemm2  (float *a, float *b, float *c, int n) {
  
	int i, j, k;
  float cij;

	for (i = 0; i < n; ++i) {
		for (j = 0; j < n; ++j) {
			cij = c[i*n+j]; /* cij = C[i][j] */
			for(k = 0; k < n; k++ ) {
				cij += a[i*n+k] * b[j*n+k]; /* cij += A[i][k]*B[j][k] */
			}
			c[i*n+j] = cij; /* C[i][j] = cij */
		}
	}
}


/*
 * gemm3
 * Algoritmo tiled and B transposed !!!!!!!!!!!!!! (uso do gemm2!)
 */


// #define BLOCKSIZE 128
// n é dimensão

void gemm3 (float *a, float *b, float *c, int n) {
  int sj, si, sk;
  int i, j, k;
  float cij;

  int BLOCKSIZE = 64;


  for (si = 0; si < n; si += BLOCKSIZE ) {      //'si' corresponde ao início dos blocos (1ºelemento), onde por sua vez corresponderá às linhas de C e de A 
    for (sj = 0; sj < n; sj += BLOCKSIZE ) {    //'sj' corresponde ao início dos blocos ('''), onde por sua vez corresponderá às colunas de C e às linhas de B
      for (sk = 0; sk < n; sk += BLOCKSIZE ) {  //'sk' corresponde ao início dos blocos ('''), onde por suas vez corresponderá às colunas de A e de B

       //estando agora definidos os blocos, vamos trabalhar neles como se de pequenas matrizes de dim 'Blocksize' se tratassem 

	      for (i = si; i < si + BLOCKSIZE ; ++i) {  //começamos por definir 'i', como sendo as linhas de C e A, limitadas no bloco, a qual terá o valor incial de 'si'

            for (j = sj; j < sj + BLOCKSIZE; ++j) { // definimos tbm 'j' de igual forma, tratando-se das colunas de C e das linhas de B, limitadas no bloco, ...
		      	
              cij = c[i*n+j];                       // cij = C[i][j] , que corresponde ao resultado de um elemento dentro do bloco definido em C 
			        
              for(k = sk; k < sk + BLOCKSIZE; k++ ) {  //definimos 'k' como as colunas de A e de B (por ser transposta), limitadas no bloco, ...
			        	
                cij += a[i*n+k] * b[j*n+k];         // cij += A[i][k]*B[j][k], ou seja é feita a multiplicação de matrizes para aquele elemento 'cij'
			        
              }
			        
              c[i*n+j] = cij;  //  C[i][j] = cij, colocando agora o resultado na posição certa da matriz C
		        }
	      }        

     
      }
    }
  }


}


/*
 * gemm4
 * Algoritmo 
 */

void gemm4  (float *a, float *b, float *c, int n) {
  fprintf (stderr, "gemm4() not supported!\n\n");
  return ;
}

/*
 * gemm5
 * Algoritmo 
 */

void gemm5  (float *a, float *b, float *c, int n) {
  fprintf (stderr, "gemm5() not supported!\n\n");
  return ;
}

/*
 * gemm6
 * Algoritmo 
 */

void gemm6  (float *a, float *b, float *c, int n) {
  fprintf (stderr, "gemm6() not supported!\n\n");
  return ;
}

/*
 * gemm7
 * Algoritmo 
 */

void gemm7  (float *a, float *b, float *c, int n) {
  fprintf (stderr, "gemm7() not supported!\n\n");
  return ;
}

/*
 * gemm8
 * Algoritmo 
 */

void gemm8  (float *a, float *b, float *c, int n) {
  fprintf (stderr, "gemm8() not supported!\n\n");
  return ;
}

/*
 * gemm9
 * Algoritmo 
 */

void gemm9  (float *a, float *b, float *c, int n) {
  fprintf (stderr, "gemm9() not supported!\n\n");
  return ;
}

/*
 * gemm10
 * Algoritmo 
 */

void gemm10  (float *a, float *b, float *c, int n) {
  fprintf (stderr, "gemm10() not supported!\n\n");
  return ;
}
