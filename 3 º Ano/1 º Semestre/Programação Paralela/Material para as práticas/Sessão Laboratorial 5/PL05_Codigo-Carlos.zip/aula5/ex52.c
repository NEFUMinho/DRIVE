#include<omp.h>
#include<stdio.h>
#define size 10 //n é criada uma variavel com o valor size, mas é mesmo colocado o valor onde diz size (no codigo em si)

double a[size], b[size];

int main() {

    // init vectors
    for(int i=0;i<size; i++) {
        a[i] = 1.0/((double) (size-i));
        b[i] = a[i] * a[i];
    }

    // compute dot product

    double dot = 0;
    
    //#pragma omp parallel for  //  neste caso, o resultado do produto vai variar. PK? Porque sabemos que vai haver uma divisão de iterações (valores de i) para cada thread e sabemos que o valor 
                              //final/output apresentado vai depende da thread que chegar primeiro à região paralela (ou seja havendo N threads, vai haver N outputs diferentes, pois dividiu-se as iterações N vezes)  

    #pragma omp parallel for reduction(+:dot) //    ja neste caso, após todas as iterações terem sido realizadas em cada thread, vai haver uma soma de todos os "dots" resultantes de cada thread,
                                                // somando tbm o valor inicial, que é 0 no caso, dando assim o valor total da multipliação dos elementos dos vetores como output.    
    for(int i=0;i<size; i++) {

        //#pragma omp critical // alinea c), como o critical está dentro do for, significa apenas que quer que uma thread faça o dot
        //#pragma omp master //utilizando o master, conseguimos realizar exatamente o mesmo que usando o critical neste caso
        dot += a[i]*b[i];
        //printf("Dot in middle is %18.16f\n",dot);  //usado para saber o que fazia o critical, nao funcionou

    }
    
    printf("Dot is %18.16f\n",dot);
}