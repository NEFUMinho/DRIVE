#include<omp.h>
#include<stdio.h>

// com N_threads=4!!!!!

int main() {

    int w=10; // a variavel w vai ser partilhada por todos os fios de execução pk esta fora da regiao paralela

#pragma omp parallel
//#pragma omp for // há distribuição de carga (com N_threads=4, então fica 25 para cada thread), porém o output depende da thread que chegar primeiro à região paralela
//#pragma omp for private(w) //o w é inicializado a 0 e tem sempre os mesmos valores (vai de 0 a 24 em cada thread, nao sendo o output apresentado ordenadamente), sendo que no fim o w retorna ao seu valor original (w=10)
//#pragma omp for firstprivate(w) //a unica diferença do de cima é que neste caso ele vai inicializar a 10
//#pragma omp for lastprivate(w) // igual ao private, porém o valor de w que vai ser retornado no fim é o ultimo w calculado na ultima thread (claro sumando 1 pk na ultima thread w=24 e o valor retornado é 25)
#pragma omp for reduction(+:w) // ver de seguida:
                                /* Cada fio vai executar o seu valor de w e no fim existe a soma de todos os valores que vai dar 100.
                                   Vai também adicionar o valor inicial (10), dando, por isso, w=110
                                   O valor inicial dos w vai ser 10.
                                   O valor vai ser sempre igual independentemente do nº de fios de execução e da quantidade de vezes que é executado. */
      
       for(int i=0;i<100;i++) {
        int id = omp_get_thread_num();
        printf("T%d:i%d w=%d\n", id, i, w++);
    }
    printf("w=%d\n", w);
}