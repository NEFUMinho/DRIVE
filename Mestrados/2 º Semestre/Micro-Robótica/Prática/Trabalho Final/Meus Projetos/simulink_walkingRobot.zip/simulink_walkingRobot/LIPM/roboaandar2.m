fclose('all'); clear all; clc
load('simoutd.mat')
% criação do objeto arduino
clear a; % Limpa a variável do arduino
a = arduino("COM6", "Uno", "BaudRate", 115200);

% Cria um objecto dos servos e conecta-os ao pino correspondente
clear lk lh lf rk rh rf; % limpa as variáveis dos servos

    % pins ligados ao lado esquerdo:
lk = servo(a,'D12'); % -> joelho 
lh = servo(a,'D9');  % -> anca
la = servo(a,'D4');  % -> pé/ankle

    % pins ligados ao lado direito:
rk = servo(a,'D8');  % -> joelho
rh = servo(a,'D7');  % -> anca
ra = servo(a,'D2');  % -> pé/ankle

% criação de arrays dos valores das matrizes:
clear arla arlh arlf arra arrh arrf; % limpa as variáveis dos arrays

% o 3 é a perna esquerda
%l_pitch = [simout{3}.Values.anklepitch_angle.data]; % criação de um intervalo de valores do pé, pois é o que se vai mover mais

% valores do knee perna esquerda
arlk = simout{3}.Values.knee_angle;       
%plot(simout{3}.Values.knee_angle.time, arlk);

% valores da hip perna esquerda
arlh = simout{3}.Values.hippitch_angle;
%plot(simout{3}.Values.hippitch_angle.time, arlh);

% valores do ankle perna esquerda
arla = simout{3}.Values.anklepitch_angle;
%plot(simout{3}.Values.anklepitch_angle.time, arla);

% o 2 é a perna direita 
%r_pitch = [simout{2}.Values.anklepitch_angle.data];  % criação de um intervalo de valores do pé, pois é o que se vai mover mais

% valores da hip perna direita
arrh = simout{2}.Values.hippitch_angle;     
%plot(simout{2}.Values.hippitch_angle.time, arrh);

% valores do knee perna direita
arrk = simout{2}.Values.knee_angle;
%plot(simout{2}.Values.knee_angle.time, arrk);

% valores do ankle perna direita
arra = simout{2}.Values.anklepitch_angle;
%plot(simout{2}.Values.anklepitch_angle.time, arra);

% Passando agora os valores dos arrays de radianos para graus:
clear vlk vlh vla vrk vrh vra x y h q i; % limpa as variáveis dos arrays de radianos para graus

    % lado esquerdo:
vla = rad2deg(arla.data);
vlh = rad2deg(arlh.data);
vlk = rad2deg(arlk.data);

    % lado direito:
vra = rad2deg(arra.data);
vrh = rad2deg(arrh.data);
vrk = rad2deg(arrk.data);

% Define os valores de offset dos servos
hipROffset = 5/180;
kneeROffset = 100/180;
ankleROffset = 80/180;
hipLOffset = 55/180;
kneeLOffset = 85/180;
ankleLOffset = 1/180;


% Estica as pernas
writePosition(lh, hipLOffset);
writePosition(rh, hipROffset);
writePosition(lk, kneeLOffset);
writePosition(rk, kneeROffset);
writePosition(la, ankleLOffset);
writePosition(ra, ankleROffset);
pause(1); % Pausa de 1 seg

% Loop que permite ao robot executar uma marcha contínua
while (1)
for i = 2679:100:3261
    walking(lh, hipLOffset+vlh(i)/180); % -> vai fazer movimentar-se a anca do lado esquerdo
    walking(rh, hipROffset-vrh(i)/180); % -> vai fazer movimentar-se a anca do lado direita
    walking(lk, kneeLOffset-vlk(i)/180); % -> vai fazer movimentar-se o joelho do lado esquerdo
    walking(rk, kneeROffset+vrk(i)/180); % -> vai fazer movimentar-se o joelho do lado direito
    walking(la, ankleLOffset-vla(i)/180); % -> vai fazer movimentar-se o ankle do lado esquerdo
    walking(ra, ankleROffset+vra(i)/180); % -> vai fazer movimentar-se o ankle do lado direito

end
end


% Função que dado um servo e um ângulo coloca o servo na posição pretendida
function walking(motor, ang)
if ang>=0
    writePosition(motor, ang);
else
    writePosition(motor, 0); % Não permite que o ângulo ultrapasse o limite
end
end
