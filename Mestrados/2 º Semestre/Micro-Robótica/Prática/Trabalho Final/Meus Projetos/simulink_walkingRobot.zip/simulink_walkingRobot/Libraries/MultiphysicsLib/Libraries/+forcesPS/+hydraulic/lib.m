function lib( libInfo )
% Customize library
% Copyright 2005-2017 The MathWorks, Inc

libInfo.Name = 'Hydraulic';
end
