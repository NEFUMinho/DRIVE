[in,valor] = findpeaks(vra,simout{2}.Values.anklepitch_angle.time);

x = valor(3);
y = valor(4);

for i = 1:1:3305
    if simout{2}.Values.anklepitch_angle.time(i) == x
        h = i;
    end
end
for i = 1:1:3305
    if simout{2}.Values.anklepitch_angle.time(i) == y
        q = i;
    end
end