fclose('all'); clear all; clc
% criação do objeto arduino
%clear a; % Limpa a variável do arduino
a = arduino("COM13", "Uno", "BaudRate", 115200);

% Cria um objecto dos servos e conecta-os ao pino correspondente
clear lk lh lf rk rh rf; % limpa as variáveis dos servos

    % pins ligados ao lado esquerdo:
lk = servo(a,'D12'); % -> joelho 
lh = servo(a,'D9');  % -> anca
la = servo(a,'D4');  % -> pé/tornozelo

    % pins ligados ao lado direito:
rk = servo(a,'D8');  % -> joelho
rh = servo(a,'D7');  % -> anca
ra = servo(a,'D2');  % -> pé/tornozelo



% Define os valores de offset dos servos

hipROffset = 37/180;
kneeROffset = 95/180;
ankleROffset = 79/180;

hipLOffset = 40/180;
kneeLOffset = 97/180;
ankleLOffset = 5/180;

% Estica as pernas

writePosition(lh, hipLOffset);
writePosition(rh, hipROffset);
writePosition(lk, kneeLOffset);
writePosition(rk, kneeROffset);
writePosition(la, ankleLOffset);
writePosition(ra, ankleROffset);

pause(1); % Pausa de 1 seg
