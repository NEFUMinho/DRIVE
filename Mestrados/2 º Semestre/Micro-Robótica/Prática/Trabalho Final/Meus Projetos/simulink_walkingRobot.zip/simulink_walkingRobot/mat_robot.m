load('simout_example.mat')
%% Downsampling - Perna Esquerda
% Ângulos da variável simout
Lankle_pitch = [simout{3}.Values.anklepitch_angle.Data]';
% Dowsampling para (nº inicial de pontos)/250 pontos e conversão para graus
Ldown_ap = rad2deg(downsample(Lankle_pitch, 250));
Lknee_angle = [simout{3}.Values.knee_angle.Data]';
Ldown_ka = rad2deg(downsample(Lknee_angle, 250));
Lhip_pitch = [simout{3}.Values.hippitch_angle.Data]';
Ldown_hp = rad2deg(downsample(Lhip_pitch, 250));
% Plot do gráfico relativo às juntas da perna esquerda
fig1 = figure(1);
plot(Ldown_ap,'.')
hold on
plot(Ldown_ka,'.')
plot(Ldown_hp,'.')
hold off
title('LEFT'); % título do gráfico
xlabel('Number of samples') % título do eixo x
ylabel('Angle (degrees)') % título do eixo y
legend('ankle', 'knee', 'hip') % legenda do gráfico

%% Downsampling - Perna Direita
Rankle_pitch = [simout{2}.Values.anklepitch_angle.Data]';
Rdown_ap = rad2deg(downsample(Rankle_pitch, 250));
Rknee_angle = [simout{2}.Values.knee_angle.Data]';
Rdown_ka = rad2deg(downsample(Rknee_angle, 250));
Rhip_pitch = [simout{2}.Values.hippitch_angle.Data]';
Rdown_hp = rad2deg(downsample(Rhip_pitch, 250));
% Plot do gráfico relativo às juntas da perna direita
fig2 = figure(2);
plot( Rdown_ap,'.')
hold on
plot(Rdown_ka,'.')
plot(Rdown_hp,'.')
hold off
title('RIGHT');
xlabel('Number of samples')
ylabel('Angle (degrees)')
legend('ankle', 'knee', 'hip')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Cria um objeto do arduino
clear a; % Limpa a variável do arduino
a = arduino('COM18', 'Uno', 'Libraries', 'Servo');
% Cria um objecto dos servos e conecta-os ao pino correspondente
clear hipL hipR kneeL kneeR ankleL ankleR; % limpa as variáveis dos servos
hipL = servo(a,'D12');
hipR = servo(a,'D3');
kneeL = servo(a,'D9');
kneeR = servo(a,'D5');
ankleL = servo(a,'D8');
ankleR = servo (a,'D6');
% Define os valores de offset dos servos
hipROffset = 90/180;
kneeROffset = 10/180;
ankleROffset = 90/180;
hipLOffset = 100/180;
kneeLOffset = 150/180;
ankleLOffset = 25/180;
% Estica as pernas
writePosition(hipL, hipLOffset);
writePosition(hipR, hipROffset);
writePosition(kneeL, kneeLOffset);
writePosition(kneeR, kneeROffset);
writePosition(ankleL, ankleLOffset);
writePosition(ankleR, ankleROffset);
pause(1); % Pausa de 1 seg

% Loop que permite ao robot executar uma marcha contínua
for i = 1:length(Rankle_pitch)
    walking(hipL, hipLOffset+Ldown_hp(i)/180);
    walking(hipR, hipROffset-Rdown_hp(i)/180);
    walking(kneeL, kneeLOffset-Ldown_ka(i)/180);
    walking(kneeR, kneeROffset+Rdown_ka(i)/180);
    walking(ankleL, ankleLOffset-Ldown_ap(i)/180);
    walking(ankleR, ankleROffset+Rdown_ap(i)/180);
end

% Função que dado um servo e um ângulo coloca o servo na posição pretendida
function walking(motor, ang)
if ang>0
    writePosition(motor, ang);
else
    writePosition(motor, 0); % Não permite que o ângulo ultrapasse o limite
end
end