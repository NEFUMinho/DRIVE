#define LhipOffset 68
#define LkneeOffset 99
#define LankleOffset 138
#define RhipOffset 103
#define RkneeOffset 92
#define RankleOffset 76.5