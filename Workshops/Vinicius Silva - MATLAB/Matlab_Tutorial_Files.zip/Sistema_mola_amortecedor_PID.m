clc; clear;
% %% PID
% 
% Kp = 1;
% Ki = 1;
% Kd = 1;
% 
% s = tf('s');
% C = Kp + Ki/s + Kd*s
% %ou
% C = pid(Kp,Ki,Kd)
% tf(C)
m = 1;
b = 10;
k = 20;
%% Sistema mola/amortecedor
% 1/Ms^2+bs+k (M=1kg; b=10N s/M; k=20 N/m; F=1N)
% Resposta Malha-Aberta
s = tf('s');
P = 1/(s^2 + 10*s + 20);
figure(1);
step(P)
%% Controlo Proporcional

Kp = 300; %12.093
C = pidstd(Kp)
T = feedback(C*P,1)

t = 0:0.01:2;
figure(2);
step(T,t)
%% Controlo Proporcional-Integral

Kp = 30;
Ti = 3/7;
C = pidstd(Kp,Ti)
T = feedback(C*P,1)

t = 0:0.01:5;
figure(3);
step(T,t)

%% Controlo Proporcial-Integral-Derivativo

Kp = 14.512; %350
Ti = 0.1156; %300
Td = 0.0289; %50
C = pidstd(Kp,Ti,Td)
T = feedback(C*P,1);

t = 0:0.01:5;
figure(4);
step(T,t)

%% M�todo malha aberta pra a sintoniza��o dos par�metros do PID

num = [0 0 1];
denm = [1 10 20];
G1 = tf(num, denm);

figure(5)
[y,t] = step(G1);
[tv, f, idx] = tangent(y, t);     % Calculate Tangent Line
t(idx)
y(idx)
plot(t, y);
hline1=refline([0 0.05]);
hline1.Color = 'black';
xline(0.7224, '--black')
hold on
plot(tv, f, '-r')                % Tangent Line
plot(t(idx), y(idx), '.r')       % Maximum Vertical
hold off
grid
axis([0 3 0 0.055]);
title('PID - m�todo 1 (malha aberta)');
legend('x(t)', 'x(t)=0.05', '','');

figure(6);
pzmap(G1);

%% PID Malha aberta

Kp = 11.14; 
Ti = 0.14; 
Td = 0.035;
C = pidstd(Kp,Ti,Td)
T = feedback(C*P,1);

t = 0:0.01:7;
figure(7);
step(T,t)

%% Controlo Proporcial-Integral-Derivativo com perturba��o de um integrador (1/s)

Kp = 120; %350
Ti = 0.702; %300
Td = 0.1756; %50
C = pidstd(Kp,Ti,Td)
PNew = P*(1/s)
T = feedback(C*PNew,1);

t = 0:0.01:7;
figure(8);
step(T,t)
%% PID Tuner

pidTuner(PNew,'pid')
%SettlingTime = tspan(find(y>0.02,1,'last'))