clear;clc;
% http://ctms.engin.umich.edu/CTMS/index.php?example=Introduction&section=ControlPID
%% Exercicio 1 (Resposta oa degrau unit�rio)

numA = [0 0 100];
demA = [1 15 100];

G1= tf(numA,demA)

figure(1);
h1 = stepplot(G1);
legend('Resposta de G1 ao degrau');
S1=stepinfo(G1,'RiseTimeLimits',[0 1])% [0.5 0.95] - limites do tempo de subida
axis([0 5 0 2]);

figure(2);
pzmap(G1);
pole(G1)
legend('polos do sistema');

%% Resposta ao impulso unit�rio
numB = [0 0 100];
demB = [1 15 100];

G2= tf(numB,demB)

figure(3);
impulse(numB,demB);
title('Resposta ao impulso unit�rio');

%% Resposta  a rampa unit�ria 
t=0:0.1:10;
alpha=1;
ramp=alpha*t;         % Your input signal
model=tf([0 0 100],[1 15 100]);    % Your transfer function
[y,t]=lsim(model,ramp,t);
figure(4);
plot(t,y,'o',t,t,'-');
title('Resposta a rampa unit�ria de G(s)=1/s+1')
legend('g(t)','r(t)');

%% Resposta a uma sinusoide
t2 = 0:0.01:20;
u = sin(t2);
model2=tf([0 0 100],[1 15 100]); 
[y2,t2]=lsim(model2,u,t2);  % u,t definem o sinal de entrada
figure(5);
plot(t2,y2,'-',t2,u,'--');
title('Resposta a uma sinusoide')
legend('g(t)','r(t)');

%% Exerc�cio 2
%1)
numC = [0 0 9];
demC = [1 6 9];

G3= tf(numC,demC)

figure(6);
h1 = stepplot(G3);
axis([0 5 0 2]);
S2=stepinfo(G3,'RiseTimeLimits',[0 1])% [0.5 0.95] - limites do tempo de subida
%damp(G3) % informa��o sobre o zeta, wn, os polos do sistema e a constante de Tempo.
legend('Resposta de G3 ao degrau');
figure(7);
pzmap(G3);
axis([-11 1 -15 15])
legend('polos do sistema');
poles=pole(G3)